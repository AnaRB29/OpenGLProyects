#include <windows.h>
#include <GL/glut.h>


///////// Variables
char title[] = "Flauros Silent Hill";
GLfloat angleOct = 0.0f;
GLfloat anglePyramid = 0.0f;


///////// Init
void initGL() {
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClearDepth(1.0f);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glShadeModel(GL_SMOOTH);
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
}



///////// Piramide 
void drawPyramid() {
    glBegin(GL_TRIANGLES);

    // Cara base
    glColor3f(0.64f, 0.16f, 0.16f);  // Dark Brown
    glVertex3f(2.0f, 2.0f, 3.0f);
    glVertex3f(-4.0f, 2.0f, 0.0f);
    glVertex3f(2.0f, 2.0f, -3.0f);

    // Cara 1
    glColor3f(0.8f, 0.4f, 0.2f);  // Light Brown
    glVertex3f(-4.0f, 2.0f, 0.0f);
    glVertex3f(0.0f, 7.0f, 0.0f);
    glVertex3f(2.0f, 2.0f, 3.0f);

    // Cara 2
    glColor3f(0.8f, 0.4f, 0.2f);  // Light Brown
    glVertex3f(2.0f, 2.0f, 3.0f);
    glVertex3f(0.0f, 7.0f, 0.0f);
    glVertex3f(2.0f, 2.0f, -3.0f);

    // Cara 3
    glColor3f(0.64f, 0.16f, 0.16f);  // Dark Brown
    glVertex3f(2.0f, 2.0f, -3.0f);
    glVertex3f(0.0f, 7.0f, 0.0f);
    glVertex3f(-4.0f, 2.0f, 0.0f);

    glEnd();
}

///////// Centro
void drawOct()
{
    glBegin(GL_TRIANGLES);

    //Octaedro
    glColor3f(0.8f, 0.4f, 0.2f);
    glVertex3f(4.0f, -4.0f, 0.0f);
    glVertex3f(2.0f, 2.0f, -3.0f);
    glVertex3f(-2.0f, -4.0f, -3.0f);

    glColor3f(0.64f, 0.16f, 0.16f);
    glVertex3f(-2.0f, -4.0f, -3.0f);
    glVertex3f(2.0f, 2.0f, -3.0f);
    glVertex3f(-4.0f, 2.0f, 0.0f);

    glColor3f(0.8f, 0.4f, 0.2f);
    glVertex3f(-2.0f, -4.0f, -3.0f);
    glVertex3f(-4.0f, 2.0f, 0.0f);
    glVertex3f(-2.0f, -4.0f, 3.0f);

    glColor3f(0.64f, 0.16f, 0.16f);
    glVertex3f(-2.0f, -4.0f, 3.0f);
    glVertex3f(-4.0f, 2.0f, 0.0f);
    glVertex3f(2.0f, 2.0f, 3.0f);

    glColor3f(0.8f, 0.4f, 0.2f);
    glVertex3f(-2.0f, -4.0f, 3.0f);
    glVertex3f(2.0f, 2.0f, 3.0f);
    glVertex3f(4.0f, -4.0f, 0.0f);

    glColor3f(0.64f, 0.16f, 0.16f);
    glVertex3f(4.0f, -4.0f, 0.0f);
    glVertex3f(2.0f, 2.0f, 3.0f);
    glVertex3f(2.0f, 2.0f, -3.0f);

    glColor3f(0.8f, 0.4f, 0.2f);
    glVertex3f(2.0f, 2.0f, 3.0f);
    glVertex3f(-4.0f, 2.0f, 0.0f);
    glVertex3f(2.0f, 2.0f, -3.0f);

    glColor3f(0.64f, 0.16f, 0.16f);
    glVertex3f(-2.0f, -4.0f, 3.0f);
    glVertex3f(4.0f, -4.0f, 0.0f);
    glVertex3f(-2.0f, -4.0f, -3.0f);

    // Piramide 1
    glColor3f(0.8f, 0.4f, 0.2f);
    glVertex3f(4.0f, -4.0f, 0.0f);
    glVertex3f(2.0f, 2.0f, -3.0f);
    glVertex3f(-2.0f, -4.0f, -3.0f);

    glColor3f(0.64f, 0.16f, 0.16f);
    glVertex3f(4.0f, -4.0f, 0.0f);
    glVertex3f(2.0f, 2.0f, -3.0f);
    glVertex3f(4.0f, -4.0f, -6.0f);

    glColor3f(0.8f, 0.4f, 0.2f);
    glVertex3f(-2.0f, -4.0f, -3.0f);
    glVertex3f(2.0f, 2.0f, -3.0f);
    glVertex3f(4.0f, -4.0f, -6.0f);

    //base
    glColor3f(0.64f, 0.16f, 0.16f);
    glVertex3f(4.0f, -4.0f, 0.0f);
    glVertex3f(4.0f, -4.0f, -6.0f);
    glVertex3f(-2.0f, -4.0f, -3.0f);

    //Piramide 2
    glColor3f(0.8f, 0.4f, 0.2f);
    glVertex3f(4.0f, -4.0f, 0.0f);
    glVertex3f(2.0f, 2.0f, 3.0f);
    glVertex3f(-2.0f, -4.0f, 3.0f);

    glColor3f(0.64f, 0.16f, 0.16f);
    glVertex3f(4.0f, -4.0f, 0.0f);
    glVertex3f(2.0f, 2.0f, 3.0f);
    glVertex3f(4.0f, -4.0f, 6.0f);

    glColor3f(0.8f, 0.4f, 0.2f);
    glVertex3f(-2.0f, -4.0f, 3.0f);
    glVertex3f(2.0f, 2.0f, 3.0f);
    glVertex3f(4.0f, -4.0f, 6.0f);

    // Base
    glColor3f(0.64f, 0.16f, 0.16f);
    glVertex3f(4.0f, -4.0f, 0.0f);
    glVertex3f(4.0f, -4.0f, 6.0f);
    glVertex3f(-2.0f, -4.0f, 3.0f);

    //Piramide 3
    glColor3f(0.8f, 0.4f, 0.2f);
    glVertex3f(-2.0f, -4.0f, -3.0f);
    glVertex3f(-4.0f, 2.0f, 0.0f);
    glVertex3f(-2.0f, -4.0f, 3.0f);

    glColor3f(0.64f, 0.16f, 0.16f);
    glVertex3f(-2.0f, -4.0f, -3.0f);
    glVertex3f(-4.0f, 2.0f, 0.0f);
    glVertex3f(-8.0f, -4.0f, 0.0f);

    glColor3f(0.8f, 0.4f, 0.2f);
    glVertex3f(-8.0f, -4.0f, 0.0f);
    glVertex3f(-4.0f, 2.0f, 0.0f);
    glVertex3f(-2.0f, -4.0f, 3.0f);
     //Base
    glColor3f(0.8f, 0.4f, 0.2f);
    glVertex3f(-2.0f, -4.0f, -3.0f);
    glVertex3f(-8.0f, -4.0f, 0.0f);
    glVertex3f(-2.0f, -4.0f, 3.0f);


    glEnd();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    // Render pyramid 
    glLoadIdentity();
    glTranslatef(0.0f, 1.0f, -30.0f);
    glRotatef(anglePyramid, 1.0f, 0.0f, 0.0f);  // Rotate the pyramid
    drawPyramid();


    //Render oct
    glLoadIdentity();
    glTranslatef(0.0f, 1.0f, -30.0f);
    glRotatef(angleOct, 1.0f, 0.0f, 0.0f);  // Rotate the pyramid
    drawOct();
    

    glutSwapBuffers();
}

/* Timer function to update the rotation angles */
void update(int value) {
    angleOct += 1.0f;
    anglePyramid += 1.0f;

    glutPostRedisplay();
    glutTimerFunc(16, update, 0);
}

/* Handler for window re-size event. */
void reshape(GLsizei width, GLsizei height) {
    if (height == 0) height = 1;
    GLfloat aspect = (GLfloat)width / (GLfloat)height;

    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0f, aspect, 0.1f, 100.0f);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(640, 480);
    glutInitWindowPosition(50, 50);
    glutCreateWindow(title);
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    initGL();
    glutTimerFunc(25, update, 0);  // Timer for rotation update
    glutMainLoop();
    return 0;
}
