#pragma once
#include <glm/glm.hpp>
class Camera
{
	glm::vec3 position;
	glm::vec3 viewDirection;
	const glm::vec3 UP;

public:
	Camera();
	glm::mat4 getWorldToViewMatrix() const;
};

